import sys
import json
import xbmc
import xbmcplugin
from .addonvar import addon_name
from .utils import add_dir
#from .parser import Parser
#from .dropbox import DownloadFile
from .addonvar import addon_icon, mediart, addon_fanart, local_string, buildpath
from .colors import colors

HANDLE = int(sys.argv[1])
COLOR1 = colors.color_text1
COLOR2 = colors.color_text2

def main_menu():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Main Menu'))
    add_dir((local_string(30069)),'','',addon_icon,addon_fanart, COLOR1('Default'), isFolder=False)  # Title 
    add_dir((local_string(30066)),'',13,mediart+"zipit.png",addon_fanart, COLOR2('Backup Build'), isFolder=False)  # Backup Build
    add_dir((local_string(30067)),'',14,mediart+"unzip.png",addon_fanart, COLOR2('Restore Backup'))  # Restore Backup
    add_dir((local_string(30068)),'','',addon_icon,addon_fanart, COLOR2('Location Backup'))  # Title 
    add_dir((buildpath),'',20,mediart+"location.png",addon_fanart, COLOR1('Default')) # Set Zip file path location_menu 

def location_menu():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Location Settings'))
    add_dir((local_string(30070)),'','',addon_icon,addon_fanart, COLOR1('Default'), isFolder=False)  # Title
    add_dir((local_string(30071)),'',16,mediart+"location.png",addon_fanart, COLOR1('Default'), isFolder=False)  # Title
    add_dir((local_string(30072)),'',17,mediart+"location.png",addon_fanart, COLOR2('Set the backup location to its default.'), isFolder=False)  # Reset Backup Location
    add_dir((local_string(30073)),'','',addon_icon,addon_fanart, COLOR1('Default'), isFolder=False)  # Title

