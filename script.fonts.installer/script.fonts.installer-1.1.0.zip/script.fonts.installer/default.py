import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os
import shutil
import xml.etree.ElementTree as ET
import json

# Addon info
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_icon = xbmcvfs.translatePath(addon.getAddonInfo('icon'))
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

# Paths
font_source = os.path.join(addon_path, 'resources', 'fonts')
font_dest = xbmcvfs.translatePath('special://home/media/Fonts/')
fontcache_path = os.path.join(font_source, 'fontcache.xml')
fontcache_dest = os.path.join(font_dest, 'fontcache.xml')
manifest_path = os.path.join(font_dest, '.font_installer_manifest.txt')


def log(msg, level=xbmc.LOGDEBUG):
    """Centralized logging function"""
    xbmc.log(f"[{addon_name}] {msg}", level)
   
    
def ensure_directory(path):
    """Ensure directory exists, create if needed"""
    try:
        os.makedirs(path, exist_ok=True)
        log(f"Directory verified/created: {path}")
        return True
    except Exception as e:
        log(f"Failed to create directory {path}: {str(e)}", xbmc.LOGERROR)
        return False
    
    
def merge_fontcache(installed_fonts):
    """Merge addon fontcache with existing fontcache (only for successfully installed fonts)"""
    log("Merging fontcache.xml...")
    
    if not installed_fonts:
        log("No fonts installed, skipping fontcache merge")
        return True
    
    if not os.path.exists(fontcache_dest):
        try:
            addon_tree = ET.parse(fontcache_path)
            addon_root = addon_tree.getroot()
            
            new_root = ET.Element('fonts')
            
            for font in addon_root.findall('font'):
                filename_elem = font.find('filename')
                if filename_elem is not None and filename_elem.text:
                    filename = filename_elem.text
                    
                    if filename in installed_fonts:
                        new_root.append(font)
            
            new_tree = ET.ElementTree(new_root)
            new_tree.write(fontcache_dest, encoding='UTF-8', xml_declaration=True)
            log(f"fontcache.xml created with {len(installed_fonts)} fonts")
            return True
            
        except Exception as e:
            log(f"Failed to create fontcache.xml: {str(e)}", xbmc.LOGERROR)
            return False
    
    try:
        addon_tree = ET.parse(fontcache_path)
        addon_root = addon_tree.getroot()
        
        dest_tree = ET.parse(fontcache_dest)
        dest_root = dest_tree.getroot()
        
        existing_filenames = set()
        for font in dest_root.findall('font'):
            filename_elem = font.find('filename')
            if filename_elem is not None and filename_elem.text:
                existing_filenames.add(filename_elem.text)
        
        added_count = 0
        for font in addon_root.findall('font'):
            filename_elem = font.find('filename')
            if filename_elem is not None and filename_elem.text:
                filename = filename_elem.text
                
                if filename not in installed_fonts:
                    continue
                
                if filename in existing_filenames:
                    continue
                
                dest_root.append(font)
                existing_filenames.add(filename)
                added_count += 1
        
        if added_count > 0:
            dest_tree.write(fontcache_dest, encoding='UTF-8', xml_declaration=True)
            log(f"Fontcache merged: {added_count} fonts added")
        else:
            log("Fontcache merge: no new fonts to add")
        
        return True
        
    except ET.ParseError as e:
        log(f"XML parsing error during merge: {str(e)}", xbmc.LOGERROR)
        return False
    except Exception as e:
        log(f"Error merging fontcache: {str(e)}", xbmc.LOGERROR)
        return False


def install_fonts():
    """Install fonts from addon to Kodi media folder"""
    log("Starting font installation...", xbmc.LOGINFO)
    
    if not ensure_directory(font_dest):
        log("Cannot create font destination directory", xbmc.LOGERROR)
        return False
    
    if not os.path.exists(fontcache_path):
        log(f"fontcache.xml not found at {fontcache_path}", xbmc.LOGERROR)
        return False
    
    installed_fonts = []
    skipped_count = 0
    failed_count = 0
    
    try:
        tree = ET.parse(fontcache_path)
        root = tree.getroot()
        
        for font in root.findall('font'):
            filename_elem = font.find('filename')
            
            if filename_elem is not None and filename_elem.text:
                filename = filename_elem.text
                src = os.path.join(font_source, filename)
                dest = os.path.join(font_dest, filename)
                
                if os.path.exists(dest):
                    skipped_count += 1
                    continue
                
                if os.path.isfile(src):
                    try:
                        shutil.copy2(src, dest)
                        installed_fonts.append(filename)
                    except Exception as e:
                        log(f"Failed to copy {filename}: {str(e)}", xbmc.LOGERROR)
                        failed_count += 1
                else:
                    log(f"Source font not found: {src}", xbmc.LOGWARNING)
                    failed_count += 1
        
        if installed_fonts:
            try:
                with open(manifest_path, 'w') as f:
                    for font_filename in installed_fonts:
                        f.write(font_filename + '\n')
                log(f"Manifest created: {len(installed_fonts)} fonts")
            except Exception as e:
                log(f"Failed to create manifest: {str(e)}", xbmc.LOGERROR)
                return False
        
        merge_fontcache(installed_fonts)
        
        log(f"Installation complete: {len(installed_fonts)} installed, {skipped_count} skipped, {failed_count} failed", xbmc.LOGINFO)
        return (len(installed_fonts), skipped_count, failed_count)
        
    except ET.ParseError as e:
        log(f"XML parsing error: {str(e)}", xbmc.LOGERROR)
        return False
    except Exception as e:
        log(f"Installation error: {str(e)}", xbmc.LOGERROR)
        return False


def reset_subtitle_font_to_default():
    """Reset Kodi subtitle font to default"""
    log("Resetting subtitle font to default...")
    
    try:
        response = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0",
            "method": "Settings.ResetSettingValue",
            "params": {
                "setting": "subtitles.fontname"
            },
            "id": 1
        }))
        
        result = json.loads(response)
        if "result" in result:
            log("Subtitle font reset to default")
            return True
        else:
            log("Failed to reset subtitle font", xbmc.LOGWARNING)
            return False
        
    except Exception as e:
        log(f"Error resetting subtitle font: {str(e)}", xbmc.LOGERROR)
        return False


def uninstall_fonts():
    """Uninstall fonts from Kodi media folder (only fonts that were installed by this addon)"""
    log("Starting font uninstallation...", xbmc.LOGINFO)
    
    reset_subtitle_font_to_default()
    
    removed_count = 0
    failed_count = 0
    fonts_to_remove = []
    
    if os.path.exists(manifest_path):
        log("Using manifest for uninstall")
        try:
            with open(manifest_path, 'r') as f:
                fonts_to_remove = [line.strip() for line in f if line.strip()]
            log(f"Manifest: {len(fonts_to_remove)} fonts to remove")
        except Exception as e:
            log(f"Failed to read manifest: {str(e)}", xbmc.LOGERROR)
    
    if not fonts_to_remove:
        log("Manifest not found - fallback to fontcache.xml")
        
        if not os.path.exists(fontcache_path):
            log("fontcache.xml not found in addon", xbmc.LOGWARNING)
            return False
        
        try:
            tree = ET.parse(fontcache_path)
            root = tree.getroot()
            
            for font in root.findall('font'):
                filename_elem = font.find('filename')
                
                if filename_elem is not None and filename_elem.text:
                    filename = filename_elem.text
                    dest = os.path.join(font_dest, filename)
                    
                    if os.path.exists(dest):
                        fonts_to_remove.append(filename)
            
            log(f"Fontcache: {len(fonts_to_remove)} fonts to remove")
            
        except ET.ParseError as e:
            log(f"XML parsing error: {str(e)}", xbmc.LOGERROR)
            return False
        except Exception as e:
            log(f"Error reading fontcache.xml: {str(e)}", xbmc.LOGERROR)
            return False
    
    if not fonts_to_remove:
        log("No fonts to remove", xbmc.LOGINFO)
        return False
    
    try:
        for filename in fonts_to_remove:
            dest = os.path.join(font_dest, filename)
            
            if os.path.exists(dest):
                try:
                    os.remove(dest)
                    removed_count += 1
                except Exception as e:
                    log(f"Failed to remove {filename}: {str(e)}", xbmc.LOGERROR)
                    failed_count += 1
        
        if os.path.exists(manifest_path):
            try:
                os.remove(manifest_path)
                log("Manifest removed")
            except Exception as e:
                log(f"Failed to remove manifest: {str(e)}", xbmc.LOGERROR)
        
        if os.path.exists(fontcache_dest):
            try:
                os.remove(fontcache_dest)
                log("fontcache.xml removed")
            except Exception as e:
                log(f"Failed to remove fontcache.xml: {str(e)}", xbmc.LOGERROR)
        
        log(f"Uninstallation complete: {removed_count} removed, {failed_count} failed", xbmc.LOGINFO)
        remaining_count = count_remaining_fonts()
        return (removed_count, failed_count, remaining_count)
        
    except Exception as e:
        log(f"Uninstallation error: {str(e)}", xbmc.LOGERROR)
        return False


def fonts_exist():
    """Check if addon fonts are installed"""
    if os.path.exists(manifest_path):
        log("Fonts detected (manifest)")
        return True
    
    if not os.path.exists(fontcache_path):
        return False
    
    try:
        tree = ET.parse(fontcache_path)
        root = tree.getroot()
        
        for font in root.findall('font'):
            filename_elem = font.find('filename')
            if filename_elem is not None and filename_elem.text:
                dest = os.path.join(font_dest, filename_elem.text)
                if os.path.exists(dest):
                    log("Fonts detected (fallback)")
                    return True
        
        return False
        
    except Exception as e:
        log(f"Error checking fonts: {str(e)}", xbmc.LOGERROR)
        return False
        

def show_install_result(installed, skipped, failed):
    """Show installation result dialog with restart option"""
    dialog = xbmcgui.Dialog()
    
    if installed == 0 and skipped > 0:
        dialog.ok(
            addon_name,
            f"[CR]No new fonts installed.[CR][CR][B][COLOR FFffd800]{skipped}[/COLOR][/B] font{'s' if skipped != 1 else ''} already exist."
        )
        return
    
    result_parts = [f"[B][COLOR FFffd800]{installed}[/COLOR][/B] font" + ("s" if installed != 1 else "")]
    
    extras = []
    if failed > 0:
        extras.append(f"{failed} failed")
    if skipped > 0:
        extras.append(f"{skipped} skipped")
    
    if extras:
        result_parts.append(f"({', '.join(extras)})")
    
    main_message = "Installed " + " ".join(result_parts) + "."
    
    restart_question = "Restart Kodi to enable new fonts in player/subtitle settings?"
    
    full_message = f"[CR]{main_message}[CR][CR]{restart_question}"
    
    if dialog.yesno(addon_name, full_message, nolabel="Later", yeslabel="Restart"):
        log("User chose to restart Kodi", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            addon_name,
            "Restarting Kodi...",
            addon_icon,
            2000
        )
        xbmc.sleep(500)
        xbmc.executebuiltin('RestartApp')
    else:
        log("User chose to restart later", xbmc.LOGINFO)


def show_uninstall_result(removed, failed, remaining):
    """Show uninstallation result dialog with restart option"""
    dialog = xbmcgui.Dialog()
    
    result_parts = [f"[B][COLOR FFffd800]{removed}[/COLOR][/B] font" + ("s" if removed != 1 else "")]
    
    extras = []
    if failed > 0:
        extras.append(f"{failed} failed")
    if remaining > 0:
        extras.append(f"{remaining} remaining")
    
    if extras:
        result_parts.append(f"({', '.join(extras)})")
    
    main_message = "Removed " + " ".join(result_parts) + "."
    
    if remaining > 0:
        restart_question = "Restart Kodi to update font list in player/subtitle settings?"
    else:
        restart_question = "Restart Kodi to refresh player/subtitle font settings?"
    
    full_message = f"[CR]{main_message}[CR][CR]{restart_question}"
    
    if dialog.yesno(addon_name, full_message, nolabel="Later", yeslabel="Restart"):
        log("User chose to restart Kodi", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            addon_name,
            "Restarting Kodi...",
            addon_icon,
            2000
        )
        xbmc.sleep(500)
        xbmc.executebuiltin('RestartApp')
    else:
        log("User chose to restart later", xbmc.LOGINFO)


def count_remaining_fonts():
    """Count how many fonts remain in destination folder after uninstall"""
    if not os.path.exists(font_dest):
        return 0
    
    try:
        font_files = [f for f in os.listdir(font_dest) 
                     if f.lower().endswith(('.ttf', '.otf'))]
        return len(font_files)
    except Exception as e:
        log(f"Error counting remaining fonts: {str(e)}", xbmc.LOGERROR)
        return 0


if __name__ == '__main__':
    log("=" * 50, xbmc.LOGINFO)
    log(f"Addon started: {addon_name}", xbmc.LOGINFO)
    
    dialog = xbmcgui.Dialog()
    
    if fonts_exist():
        # UNINSTALL MODE
        log("Fonts detected - uninstall mode", xbmc.LOGINFO)
        
        if dialog.yesno(
            addon_name,
            "[CR]Are you sure you want to uninstall subtitle fonts?",
            nolabel="Cancel",
            yeslabel="Uninstall"
        ):
            log("User confirmed uninstall", xbmc.LOGINFO)
            
            result = uninstall_fonts()
            
            if result and isinstance(result, tuple):
                removed, failed, remaining = result
                show_uninstall_result(removed, failed, remaining)
            else:
                dialog.ok(addon_name, "[CR]Uninstallation failed. Check log for details.")
        else:
            log("User cancelled uninstall", xbmc.LOGINFO)
    
    else:
        # INSTALL MODE
        log("Fonts not detected - install mode", xbmc.LOGINFO)
        
        if dialog.yesno(
            addon_name,
            "[CR]Do you want to install additional subtitle fonts?",
            nolabel="Cancel",
            yeslabel="Install"
        ):
            log("User confirmed install", xbmc.LOGINFO)
            
            result = install_fonts()
            
            if result and isinstance(result, tuple):
                installed, skipped, failed = result
                show_install_result(installed, skipped, failed)
            else:
                dialog.ok(addon_name, "[CR]Installation failed. Check log for details.")
        else:
            log("User cancelled install", xbmc.LOGINFO)
    
    log("Addon finished", xbmc.LOGINFO)
    log("=" * 50, xbmc.LOGINFO)
